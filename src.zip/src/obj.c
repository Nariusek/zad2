/* obj.c */
#include<stdio.h>
void obj(int x)
{
			int y;
			y = x*x*x;
			printf("objentosc:  %d\n",y);
}
