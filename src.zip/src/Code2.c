#include "biblioObj.h"
 #include "biblioO.h"
 #include <stdio.h>
 int main()
 {
	int x;
	printf("podaj dlugosc boku:");
	scanf("%d",&x);
	pole(x);
	obj(x);
 }
