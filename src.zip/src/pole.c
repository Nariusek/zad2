/* pole.c */
 #include <stdio.h>
 void pole(int x)
 {
			int y;
			y = x*x;
			printf("pole kwadratu:   %d\n",y);
}
