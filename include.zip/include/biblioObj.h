void obj(int x);
