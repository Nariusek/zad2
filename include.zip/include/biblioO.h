void pole(int x); 
